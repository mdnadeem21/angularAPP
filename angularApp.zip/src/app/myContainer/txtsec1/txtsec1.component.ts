import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-txtsec1',
  templateUrl: './txtsec1.component.html',
  styleUrls: ['./txtsec1.component.css']
})
export class Txtsec1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
