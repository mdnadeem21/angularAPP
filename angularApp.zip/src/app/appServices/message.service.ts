export class MessageService{
    messageAlert(){
        alert("Thanks for Subscribe. We will get in touch with you shortly")
    }
}