import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-washing-machine',
  templateUrl: './washing-machine.component.html',
  styleUrls: ['./washing-machine.component.css']
})
export class WashingMachineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
